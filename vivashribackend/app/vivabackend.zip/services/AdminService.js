export const getAllAdmin = async () => {
  // return await AdminModel.find();
  return true;
};
